$(document).ready(function(){
	
	$("#servico").click(function(){
		$.get("http://dicionario-aberto.net/search-json/casa",function(data,status){
			
			var palavra = document.getElementById("palavra");
			console.log(status);
			if(status == "success")
			{
				for(var i = 0;i<data.length;i++)
				{
					if(palavra == data[i].id)
					{
						document.getElementById("definicao").value = data[i].form;
					}
				}
				
				
				
			}
			else
			{
				
				
				
			}
			
			
			
			
		});
		
		
	});
	
	
});