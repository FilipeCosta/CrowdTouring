$(document).ready(function(){
	
	$("#btn1").click(function()
	{
		$("table").css("border","5px solid green");
	});
	
	$("#btn2").click(function()
	{
		$("td:nth-child(2)").css("background-color","orange");
	});
	
	$("#btn3").click(function()
	{
		$("tr td").first().css("background-color","red");
	});
	
	$("#btn4").click(function()
	{
		$("tr:not(#cabecalho)").click(function()
	{
		
		alert($(this).find("td:not(:first)").text());
	});
	
	});
	
	
	
	$("#btn5").click(function()
	{
		var nome = "";
		var nota = "";
		nome = prompt("nome","Alexandre");
		nota = prompt("nota","20");
		$("table").append("<tr><td>" + nome + "</td><td>" + nota +"</td></tr>");
	});

	
	$("#btn6").click(function()
	{
		$("tr:not(#cabecalho)").click(function(){
			$(this).remove();
	});
	});
	
	
	$("#btn7").click(function()
	{
		var nome = "";
		var nota = "";
		nome = prompt("nome","Alexandre");
		nota = prompt("nota","20");
		$("tr:not(#cabecalho)").click(function(){
			$(this).find("td:first").text(nome);
			$(this).find("td:not(:first)").text(nota);
	});
	});
	
	
	
	
	
	
	
});