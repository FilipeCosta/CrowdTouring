function Disciplina(disciplina,topicos)
{
	this.disciplina = disciplina;
	this.topicos = topicos;
}

var arr = [];

function adicionarDisciplina()
{
var disciplina = document.getElementById("disciplina").value;

var obj = new Disciplina(disciplina,[]);
arr.push(obj);
}


function adicionarTópico()
{
var disciplina = document.getElementById("disciplina").value;
var Topico = document.getElementById("topico").value;
var existeDisciplina = false;
var existeTopico = false;


for(var i = 0;i<arr.length;i++)
{
	if(arr[i].disciplina == disciplina)
	{
		arr[i].topicos.push(Topico);
		existeDisciplina = true;
	}
	
	if(arr[i].topicos.indexOf(Topico) != -1)
	{
		existeTopico = true;
	}
	
}

if(existeDisciplina == false)
{
	alert("não pode adicionar tópicos para disciplinas inexistentes");
}

if(existeTopico == false)
{
	alert("topico ja existe");
}

	
}


function remocao()
{
var disciplina = document.getElementById("disciplina").value;
var Topico = document.getElementById("topico").value;
var existe = false;


for(var i = 0;i<arr.length;i++)
{
	console.log(arr[i].disciplina);
		console.log(disciplina);
		console.log(arr[i].topicos);
		console.log(Topico);
	if(arr[i].disciplina == disciplina)
	{
		if(arr[i].topicos.indexOf(Topico) != -1)
		 {
			arr[i].topicos.splice(arr[i].topicos.indexOf(Topico),1);
			existe = true;
		 }
		 
		 if(arr[i].topicos.length == 0)
		 {
			 delete arr[i];
		 }
	}
	
	console.log(arr[0]);
	
}

if(existe == false)
{
	alert("tópico inexistente");
}
}


function listarTopicos()
{
	var text = "";
	var disciplina = document.getElementById("disciplina").value;
	for(var i = 0;i<arr.length;i++)
	{
		if(disciplina == arr[i].disciplina)
		{
		text += arr[i].disciplina + ": " + arr[i].topicos;
		}
	}
	
	document.getElementById("listaTopicos").value = text;
	
}


function guardar()
{
	if(typeof(Storage) != "undefined")
	{
		for(var i = 0;i<arr.length;i++)
		{
			localStorage.setItem(i.toString(),JSON.stringify(arr[i]));
		}
	}
	else
	{
		alert("browser não suporta a API Web Storage");
	}
}

function recuperaDados()
{
	if(typeof(Storage) != "undefined")
	{
		for(var i = 0;i<localStorage.length;i++)
		{
			
			arr[i] =  JSON.parse(localStorage.getItem(i.toString()));
		}
	}
	else
	{
		alert("browser não suporta a API Web Storage");
	}
}