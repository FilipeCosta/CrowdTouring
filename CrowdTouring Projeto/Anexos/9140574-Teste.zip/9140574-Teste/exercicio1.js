function resultado()
{
   var moeda = document.getElementById("caixa").value;
   var valor = document.getElementById("valor").value;
   valor = parseFloat(valor);
   var resultado = document.getElementById("resultado").value;
   console.log(moeda);
   if(moeda == "Libra")
   {
       resultado = valor * 0.70234; 
   }
   else if(moeda == "Franco")
   {
       resultado = valor * 1.08723;
   }
   else if(moeda == "Coroa")
   {
       resultado = valor * 9.27115;
   }
   else if(moeda == "Rublo")
   {
       resultado = valor * 69.90015;
   }
   else if(moeda == "Leu")
   {
       resultado = valor * 4.44305;
   }
   
   document.getElementById("resultado").value = resultado;
}