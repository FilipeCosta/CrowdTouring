// Variáveis globais

var MeshDataPac =
[
  "------------------------------",
  "-ooooooooooooo--ooooooooooooo-",
  "-o----o------o--o------o----o-",
  "-o----o------o--o------o----o-",
  "-oooooooooooooooooooooooooooo-",
  "-o----o--o----------o--o----o-",
  "-oooooo--ooooo--ooooo--oooooo-",
  "------o------ -- ------o------",
  "------o-              -o------",
  "------o-  ----  ----  -o------",
  "-     o-  -    e   -  -o     -",
  "------o-  ----------  -o------",
  "------o-              -o------",
  "------o-  ----------  -o------",
  "-ooooooooooooo--ooooooooooooo-",
  "-o----o------o--o------o----o-",
  "-ooo--oooooooo--ooooooooooooo-",
  "---o--oooo          oooo------",
  "---o--o--o-----------o-o--o---",
  "-oooooo--ooooo--oooooo-o--ooo-",
  "-o-----------o--o-----------o-",
  "-oooooooooooooooXoooooooooooo-",
  "------------------------------"
];

var contagem = 0;

var scene,renderer,camera,light,axes,PacScene,PacMan,direccao,direccaoPac,orbitCamera,wallSound,intro,gamesong,inimigoCena,changeCamera,cameraSet,inimigo;
var pontuacao = 0;
var clock = new THREE.Clock();
const SCALE = 10;
const CORPACMAN = 0xffff00;
const VELOCIDADEPAC = 0.5;
const TAMANHOPAC = 2;
const ALTURAPAC = 0;
const INIMIGOS = 4;
const LUZ = 0.5;
const TAMANHOINIMIGO = 10;


// Inicio do programa
window.onload = function init()
{
  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.x = 0;
  camera.position.y = 0;
  camera.position.z = 300;
  camera.up = new THREE.Vector3(0,1,0);
  camera.lookAt(scene.position);
  orbitCamera = new THREE.OrbitControls(camera);
  orbitCamera.target= new THREE.Vector3(0,0,0);
  orbitCamera.maxDistance=500;

  light = new THREE.AmbientLight(0xffffff);
  light.intensity = LUZ;
  scene.add( light );

  axes = new THREE.AxisHelper( 40 );
  axes.position.set(0,0,30);
  scene.add(axes);

  desenhaMapa();
  handleSongs();

  renderer = new THREE.WebGLRenderer();
  renderer.setClearColor(0xEEEEEE);
  renderer.setSize(window.innerWidth, window.innerHeight);

  var texturaPlano = new THREE.TextureLoader().load("texturaPac.jpg");
  texturaPlano.wrapS = THREE.RepeatWrapping;
  texturaPlano.wrapT = THREE.RepeatWrapping;
  texturaPlano.repeat.set(50,50);

  var geometryPlano = new THREE.PlaneGeometry(MeshDataPac[0].length * SCALE, MeshDataPac.length*SCALE);
  var materialPlano = new THREE.MeshPhongMaterial({map:texturaPlano});
  var planoPacMan = new THREE.Mesh(geometryPlano,materialPlano);
  scene.add(planoPacMan);


  document.body.appendChild( renderer.domElement );
  renderer.render(scene, camera);
  document.onkeypress = handleKeyPressed;


  anima();

}


function desenhaMapa()
{
  PacScene = new THREE.Object3D();

  var materialInimigo = new THREE.MeshPhongMaterial({color:  0x89cff0});


  var loader = new THREE.JSONLoader();
        loader.load('Enemy.json', function (geometry) {
            inimigo = new THREE.Mesh(geometry,materialInimigo);
            inimigo.scale.x = TAMANHOINIMIGO;
            inimigo.scale.y = TAMANHOINIMIGO;
            inimigo.scale.z = TAMANHOINIMIGO;
            inimigo.rotation.y = Math.PI;

  var Box = new THREE.TextureLoader().load("Box.jpg");

  geometry = new THREE.BoxGeometry( SCALE, SCALE, SCALE );
  material = new THREE.MeshPhongMaterial( {
                                            color: 0xffffff,
                                            wireframe: false,
                                            map: Box
                                        } );

  var PacManGeometry = new THREE.SphereGeometry(TAMANHOPAC,40,40);
  var PacManMaterial = new THREE.MeshPhongMaterial({color: CORPACMAN});
  PacMan = new THREE.Mesh(PacManGeometry,PacManMaterial);
  PacMan.position.y = ALTURAPAC;
  PacMan.name = "PacMan";


  var bolasGeometry = new THREE.SphereGeometry(0.5,16,16);
  var bolaMaterial = new THREE.MeshPhongMaterial( {
                                            color: 0xdcfecc,
                                        } );
  var bolaCollecao = new THREE.Mesh(bolasGeometry,bolaMaterial);

  var meshCubo =  new THREE.Mesh(geometry, material);

  for ( var i = 0; i < MeshDataPac.length; i++ )
  {
    for ( var j = 0; j < MeshDataPac[i].length; j++ )
    {
        if ( MeshDataPac[i][j] == "-" ) // mazecubo
        {
            var mazecubo = meshCubo.clone();
            mazecubo.position.set(j*SCALE,-i*SCALE,SCALE);
            PacScene.add(mazecubo);
        }

      if(MeshDataPac[i][j] == "X")
        {
        PacMan.position.set(j*SCALE,-i*SCALE,SCALE);
        PacScene.add(PacMan);
        }

       if ( MeshDataPac[i][j] == "o" ) // mazecollectable
        {
            var MeshColecao = bolaCollecao.clone();
            MeshColecao.position.set(j*SCALE,-i*SCALE,SCALE + ALTURAPAC*2);
            MeshColecao.name = "collectable" + i + "#" + j;
            PacScene.add(MeshColecao);
            contagem++;
        }

      if ( MeshDataPac[i][j] == "e" ) // mazecollectable
        {
            inimigoCena = inimigo.clone();
            inimigoCena.position.set(j*SCALE,-i*SCALE,SCALE);
            inimigoCena.name = "inimigo";
            PacScene.add(inimigoCena);
        }

    }
  }
});
  scene.add(PacScene);
  PacScene.position.set( -MeshDataPac[0].length*SCALE/2, MeshDataPac.length*SCALE/2, (SCALE/2)-SCALE);
  scene.add(camera);

}


function handleSongs()
{
   var listener = new THREE.AudioListener();
	camera.add( listener );
  var audioLoader = new THREE.AudioLoader();
  wallSound = new THREE.Audio( listener );
				audioLoader.load('Sounds/WallColision.wav', function( buffer ) {
					wallSound.setBuffer( buffer );
					wallSound.setLoop(true);
          wallSound.setVolume(0.5);
});

  var listener2 = new THREE.AudioListener();
	camera.add( listener2 );
  var audioLoader2 = new THREE.AudioLoader();
  intro = new THREE.Audio( listener );
				audioLoader2.load('Sounds/intro.wav', function( buffer ) {
					intro.setBuffer( buffer );
					intro.setLoop(false);
          intro.setVolume(0.5);
          intro.play();
});


  listener3 = new THREE.AudioListener();
	camera.add( listener3 );
  var audioLoader3 = new THREE.AudioLoader();
  gameSong = new THREE.Audio( listener3 );
				audioLoader3.load('Sounds/chomp.wav', function( buffer ) {
					gameSong.setBuffer( buffer );
					gameSong.setLoop(false);
          gameSong.setVolume(0.5);
});
}

 function handleKeyPressed(e) {

   var PacMan = scene.getObjectByName('PacMan');
   gameSong.play();
   switch(String.fromCharCode(e.which))
   {
     case "w": if(!detectaColisao(PacMan.position.x, PacMan.position.y + SCALE))
          PacMan.position.y += SCALE;
       break;
     case "a": if(!detectaColisao(PacMan.position.x - SCALE, PacMan.position.y))
         PacMan.position.x -= SCALE;
       break;
     case "s": if(!detectaColisao(PacMan.position.x, PacMan.position.y - SCALE))
         PacMan.position.y -= SCALE;
       break;
     case "d": if(!detectaColisao(PacMan.position.x + SCALE, PacMan.position.y))
         PacMan.position.x += SCALE;
       break;
     case "x": scene.remove(camera)
               PacMan.add(camera);
               camera.position.z = ALTURAPAC;
               camera.position.y = ALTURAPAC - 10;
       break;
     case "c": PacMan.remove(camera)
               camera.position.y = 0;
               camera.position.z = 300;
               scene.add(camera);


   }
}


function detectaColisao(x,y)
{
  var j = parseInt(x/SCALE);
  var i = parseInt(-y/SCALE);

  if(MeshDataPac[i][j] == '-')
  {
    wallSound.play();
    setTimeout(function(){wallSound.stop();}, 500);
    return true;
  }
  else if (MeshDataPac[i][j] == 'o') {
    var selectedObject = PacScene.getObjectByName("collectable" + i + "#" + j);
    console.log(selectedObject.position.x);
    PacScene.remove(selectedObject);
    MeshDataPac[i] = replaceAt(MeshDataPac[i],j,' ');
    pontuacao++;
  }

  return false;
}

function replaceAt(s,n,t) {

  return s.substring(0,n) + t + s.substring(n+1);
}

function moveEnemys(inimigo)
{
  console.log(inimigo.position.x);

//   var x = enemy.position.x += SCALE;
//   var y = enemy.position.y += SCALE;
//   var j = parseInt(x/SCALE);
//   var i = parseInt(-y/SCALE);

//   var pos1 = MeshDataPac[i][j+1];
//   var pos2 = MeshDataPac[i][j-1];
//   var pos3 = MeshDataPac[i+1][j];
//   var pos4 = MeshDataPac[i-1][j];

//   var posicoes = {pos1,pos2,pos3,pos4};

//   var aleatorio = Math.floor(Math.random() * 3);
//   var proximaPosicao = posicoes[aleatorio];
}

function anima()
{
  var delta=clock.getDelta();
  orbitCamera.update(delta);

  requestAnimationFrame( anima);
  renderer.render(scene, camera);

}
