var gl;
var modelView;
var Projection;
var modelo = {rotacao:0, escala:1, incEscala:0.01, 
	          translacao:0, incTranslacao:0.01};

var transformacao="Rotação";
var projxy=2.5;
var mv=mat4();
var proj=mat4();

window.onload = function init()
{
	var canvas = document.getElementById('gl-canvas');
	gl=WebGLUtils.setupWebGL(canvas);

	if(!gl)	{alert("WebGL não está disponível"); }

	document.onkeypress	=handleKeyDown;

	var vertices= new Float32Array([0.5*Math.cos(0),0.5*Math.sin(0),
									0.5*Math.cos(2*Math.PI/3),0.5*Math.sin(2*Math.PI/3),
									0.5*Math.cos(-2*Math.PI/3),0.5*Math.sin(-2*Math.PI/3)]);
	var cores= new Float32Array([1,0,0,1,
								 0,1,0,1,
								 0,0,1,1]);

	// Configurar o WebGL

	gl.viewport( 0, 0, canvas.width, canvas.height);
	gl.clearColor(0.8, 0.8, 0.8, 1.0);

	// Carregar os shaders e incializar os buffers de atributos

	var program = initShaders( gl, "vertex-shader", "fragment-shader");

	gl.useProgram(program);

	// Carregar dados para o GPU

	var vertexBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);

	// Associar variáveis do shader aos Buffers de dados

	var vPosition = gl.getAttribLocation(program, "vPosition");
	gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);

	var colorBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, cores, gl.STATIC_DRAW);

	var vColor = gl.getAttribLocation(program, "vColor");
	gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vColor);

	modelView = gl.getUniformLocation(program, "ModelView");
	projection = gl.getUniformLocation(program, "Projection");

	resize_canvas();
	
	// Pede para registar um timer que invoca a função animação
	requestAnimFrame(animacao);
}

function resize_canvas() {
	var canvas = document.getElementById("gl-canvas");
	if (canvas.width  < window.innerWidth)
	{
	    canvas.width  = window.innerWidth*.6;
	}

	if (canvas.height < window.innerHeight)
	{
	    canvas.height = window.innerHeight*.6;
	}

	gl.viewport( 0, 0, canvas.width, canvas.height);
	setProjection();
}

function setProjection() {
	var canvas = document.getElementById("gl-canvas");
	var ratio;
	var str="<b>Projeccao:</b> <br>";

	if(canvas.width>canvas.height)
	{
		ratio=canvas.width/canvas.height;
		proj=ortho( -projxy*ratio, projxy*ratio, -projxy, projxy, 1, -1 );
		str+="x: " + -projxy*ratio +" a "+ projxy*ratio + "<br>y: "+ -projxy + " a " +projxy;
	}
	else
	{
		ratio=canvas.height/canvas.width;
		proj=ortho( -projxy, projxy, -projxy*ratio, projxy*ratio, 1, -1 );
		str+=" x: " + -projxy +" a "+ projxy + "<br>y: "+ -projxy*ratio + " a " +projxy*ratio;
	}
	gl.uniformMatrix4fv(projection,false,flatten(proj));

	str+="<br>ratio: "+ratio;

	document.getElementById("projeccao").innerHTML=str;
}

function handleKeyDown(e) {

	switch( String.fromCharCode(e.which)) {
		case "r" :
		case "R" :
				transformacao="Rotação";
			break;
		case "s" :
		case "S" :
				transformacao="Escalamento";
			break;
		case "t" :
		case "T" :
				transformacao="Translação";
			break;
		case "1" :
				transformacao="Rotacao * Translação";
			break;
		case "2" :
				transformacao="Translacao * Rotação";
			break;
		case "p" :
				if(projxy>1)
					projxy-=0.5;
				setProjection();
			break;
		case "P" :
				if(projxy<5)
					projxy+=0.5;
				setProjection();
			break;
	}

	document.getElementById("transformacao").innerHTML=transformacao;
	console.log("Tecla Pressionada: "+e.keyCode + " String" + String.fromCharCode(e.which));

}

function animacao()
{
	switch(transformacao)
	{
		case "Rotação" :
			modelo.rotacao++;
			mv=rotate(modelo.rotacao,[0,1,0]);
		break;

		case "Escalamento" :
			modelo.escala+=modelo.incEscala;
			if(modelo.escala>2 || modelo.escala<0.5) 
				modelo.incEscala=-modelo.incEscala;
			mv=scalem([modelo.escala,modelo.escala,modelo.escala]);
		break;

		case "Translação":
			modelo.translacao+=modelo.incTranslacao;
			if(modelo.translacao>0.5 || modelo.translacao<-0.5) 
				modelo.incTranslacao=-modelo.incTranslacao;
			mv=translate([modelo.translacao,modelo.translacao,0]);
		break;

		case "Rotacao * Translação":
			modelo.rotacao++;
			if(modelo.rotacao>360) modelo.rotacao-=360;
			mv=rotate(modelo.rotacao,[0,0,1]);
			mv=mult(mv,translate([0.5,0,0]));
		break;
		case "Translacao * Rotação":
			modelo.rotacao++;
			if(modelo.rotacao>360) modelo.rotacao-=360;
			mv=translate([0.5,0,0]);
			mv=mult(mv,rotate(modelo.rotacao,[0,0,1]));
		break;
	}
	render();
	requestAnimFrame(animacao);
}

function render()
{
	//	console.log(transformacao+" - mat: "+matriz);

	gl.clear(gl.COLOR_BUFFER_BIT);

	gl.uniformMatrix4fv(modelView,false,flatten(mv));
	gl.drawArrays(gl.TRIANGLES, 0, 3);
}