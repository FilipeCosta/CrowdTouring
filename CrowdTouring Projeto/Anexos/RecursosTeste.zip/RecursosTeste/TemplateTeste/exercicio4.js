var scene, renderer, camera,esfera,CilindroB,CilindroC;
var caixa;
var tecla;
var incRotacao = Math.PI/180;

const CAIXALARGURA = 30;
const CAIXALTURA = 20;
const CAIXAPROFUNDIDADE = 30;

const RAIOCILINDROB = 5;
const ALTURACILINDROB = 10;

const RAIOCILINDROC = 2.5;
const ALTURACILINDROC = 50;

window.onload = function init() {

  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 10000 );
  camera.position.set(50,50,150);
  camera.up=new THREE.Vector3(0,1,0);
  camera.lookAt(new THREE.Vector3(0, 0, 0));

  var light = new THREE.DirectionalLight( 0xffffff, 5);
  light.position.set(1, 1, 0);
  light.intensity=1;
  scene.add(light);

  var textureCylinder = new THREE.TextureLoader().load("imgs/CylinderTexture.png");
  var textureBox = new THREE.TextureLoader().load("imgs/BoxTexture.jpg");
  var textureEsfera = new THREE.TextureLoader().load("imgs/SphereTexture.png");

  var geometry = new THREE.BoxGeometry( CAIXALARGURA, CAIXAPROFUNDIDADE, CAIXALTURA );
  var material = new THREE.MeshPhongMaterial( { color: 0xff0000,map:textureBox} );
  caixa = new THREE.Mesh( geometry, material );
  scene.add( caixa );

  geometry = new THREE.CylinderGeometry(RAIOCILINDROB,2,ALTURACILINDROB);
  material = new THREE.MeshPhongMaterial({ color: 0xffffff,map:textureCylinder});
  CilindroB = new THREE.Mesh(geometry, material);

  geometry = new THREE.CylinderGeometry(RAIOCILINDROC,2,ALTURACILINDROC);
  material = new THREE.MeshPhongMaterial({ color: 0xffffff,map:textureCylinder});
  CilindroC = new THREE.Mesh(geometry, material);
  CilindroC.rotation.z = -0.5 * Math.PI;

  geometry = new THREE.SphereGeometry(30,22,22);
  material = new THREE.MeshPhongMaterial({ color: 0xffffff,map:textureEsfera});
  esfera = new THREE.Mesh(geometry, material);
  esfera.position.z = RAIOCILINDROC*2;
  CilindroC.add(esfera);


  pivotPoint = new THREE.Object3D();
  pivotPoint.position.set(RAIOCILINDROB,ALTURACILINDROB,0);
  pivotPoint.add(CilindroB);
  pivotPoint.add(CilindroC);

  scene.add(pivotPoint);


  renderer = new THREE.WebGLRenderer();
  renderer.setSize( window.innerWidth, window.innerHeight );

  document.onkeypress=handleKeyPressed;
  document.body.appendChild( renderer.domElement );
  animate();
}

function handleKeyPressed(e) {

	switch( String.fromCharCode(e.which)) {
		case "Q" :
          tecla = "Q";
        break;
    case "A" :
          tecla = "A";
        break;
    case "R" :
          tecla = "R";
        break;
  }
  console.log("Keypress: "+String.fromCharCode(e.which));
}

function animate() {

  if(tecla == "Q")
  {
    while(pivotPoint.rotation.x < -Math.PI/3)
    {
     pivotPoint.rotation.x += incRotacao;
    }
  }

  if(tecla == "R" && pivotPoint.rotation.x == -Math.PI/3)
  {
    incRotacao = -incRotacao;
    while(pivotPoint.rotation != 0)
    {
    pivotPoint.rotation.x += incRotacao;
    }
  }



  requestAnimationFrame( animate );

  renderer.render( scene, camera );

}
