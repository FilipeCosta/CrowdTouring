var scene, renderer, camera;
var caixa;

const CAIXALARGURA = 30;
const CAIXALTURA = 20;
const CAIXAPROFUNDIDADE = 30;

const RAIOCILINDROB = 5;
const ALTURACILINDROB = 10;

const RAIOCILINDROC = 2.5;
const ALTURACILINDROC = 50;

window.onload = function init() {

  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 10000 );
  camera.position.set(50,50,150);
  camera.up=new THREE.Vector3(0,1,0);
  camera.lookAt(new THREE.Vector3(0, 0, 0));

  var light = new THREE.DirectionalLight( 0xffffff, 1.5);
  light.position.set(1, 1, 0);
  scene.add(light);

  var geometry = new THREE.BoxGeometry( CAIXALARGURA, CAIXAPROFUNDIDADE, CAIXALTURA );
  var material = new THREE.MeshPhongMaterial( { color: 0xff0000} );
  caixa = new THREE.Mesh( geometry, material );
  scene.add( caixa );

  geometry = new THREE.CylinderGeometry(RAIOCILINDROB,2,ALTURACILINDROB);
  material = new THREE.MeshPhongMaterial({ color: 0xffffff});
  CilindroB = new THREE.Mesh(geometry, material);

  geometry = new THREE.CylinderGeometry(RAIOCILINDROC,2,ALTURACILINDROC);
  material = new THREE.MeshPhongMaterial({ color: 0xffffff});
  CilindroC = new THREE.Mesh(geometry, material);
  CilindroC.rotation.z = -0.5 * Math.PI;


  pivotPoint = new THREE.Object3D();
  pivotPoint.position.set(RAIOCILINDROB,ALTURACILINDROB,0);
  pivotPoint.add(CilindroB);
  pivotPoint.add(CilindroC);

  scene.add(pivotPoint);


  renderer = new THREE.WebGLRenderer();
  renderer.setSize( window.innerWidth, window.innerHeight );

  document.body.appendChild( renderer.domElement );
  animate();
}

function animate() {

  requestAnimationFrame( animate );

  renderer.render( scene, camera );

}
