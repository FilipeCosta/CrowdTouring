var scene, renderer, camera;

window.onload = function init() {

  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 10000 );




  renderer = new THREE.WebGLRenderer();
  renderer.setSize( window.innerWidth, window.innerHeight );

  document.body.appendChild( renderer.domElement );
  animate();
}

function animate() {

  requestAnimationFrame( animate );

  renderer.render( scene, camera );

}
