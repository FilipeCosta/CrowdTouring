window.onload = function () {
    var canvas = document.getElementById('myCanvas');
    if (canvas.getContext) {
		var ctx = canvas.getContext('2d');
        
        var lastMouseX;
        var lastMouseY;
        
        function Rect(x,y,l,h,cor)
        {
            this.x = x;
            this.y = y;
            this.l = l;
            this.h = h;
            this.cor = cor;
            this.selected = false;
            this.desenha = function()
            {
                ctx.beginPath();
                ctx.fillStyle = this.cor;
                ctx.fillRect(this.x,this.y,this.l,this.h);
            }
        }
        
        Rect.prototype.isInside = function(mx,my)
        {
            if(this.y <= my && this.y + this.h >= mx && this.x <= mx && this.x + this.l >= mx)
            {
                ctx.beginPath();
                return true;
            }
            else
            {
                return false;
            }
        }
        
        canvas.addEventListener('mousedown',mouseDown);
        
        function mouseDown(evt)
        {
            lastMouseX = evt.pageX - canvas.offsetLeft;
            lastMouseY = evt.pageY - canvas.offsetTop;
            for(var i = 0;i<arr.length;i++)
            {
               if(arr[i].isInside(lastMouseX,lastMouseY))
               {
                   arr[i].selected = true;
                   ctx.strokeStyle = "yellow";
                   ctx.lineWidth = 10;
                   ctx.strokeRect(arr[i].x, arr[i].y, arr[i].l, arr[i].h);
                   canvas.addEventListener('mousemove',mouseMove);
               }
               
            }
        }
        
        function mouseMove(evt)
        {
            var x = evt.pageX - canvas.offsetLeft;
            var y = evt.pageY - canvas.offsetTop;
            var changeX = x - lastMouseX;
            var changeY = y - lastMouseY;
            lastMouseX = x;
            lastMouseY = y;
            for(var i = 0;i<arr.length;i++)
            {
                if(arr[i].selected)
                {
                   
                    arr[i].x += changeX;
                    arr[i].y += changeY;
                  
                }
            }
        }
        
        function mouseUp(evt)
        {
            for(var i = 0;i<arr.length;i++)
            {
                arr[i].selected = false;
                canvas.removeEventListener('mousemove');
            }
        }
        
        canvas.addEventListener('mouseup',mouseUp);
        
        var arr = [];
        var r1 = new Rect(100,100,40,80,"blue");
        var r2 = new Rect(200,200,40,80,"red");
        arr.push(r1);
        arr.push(r2);
        arr[0].desenha();
        arr[1].desenha();
        
        
        
        function anima()
        {
            ctx.clearRect(0,0,canvas.width,canvas.height);
            
            for(var i = 0;i<arr.length;i++)
            {
                arr[i].desenha();
            }
            window.requestAnimationFrame(anima);
        }
        
        window.requestAnimationFrame(anima);
    }
}