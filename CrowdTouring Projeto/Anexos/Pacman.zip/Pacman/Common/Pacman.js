var PacmanMap =
[
  "                                ",
  " ------------------------------ ",
  " -ooooooooooooo--ooooooooooooo- ",
  " -o----o------o--o------o----o- ",
  " -o----o------o--o------o----o- ",
  " -oooooooooooooooooooooooooooo- ",
  " -o----o--o----------o--o----o- ",
  " -oooooo--ooooo--ooooo--oooooo- ",
  " ------o------ -- ------o------ ",
  " ------o-              -o------ ",
  " ------o-  ----  ----  -o------ ",
  " -     o-  -        -   o       ",
  " ------o-  ----------  -o------ ",
  " ------o-              -o------ ",
  " ------o-  ----------  -o------ ",
  " -ooooooooooooo--ooooooooooooo- ",
  " -o----o------o--o------o----o- ",
  " -ooo--oooooooo--ooooooooooooo- ",
  " ---o--oooo          oooo------ ",
  " ---o--o--o-----------o-o--o--- ",
  " -oooooo--ooooo--oooooo-o--ooo- ",
  " -o-----------o--o-----------o- ",
  " -oooooooooooooooooooooooooooo- ",
  " ------------------------------ ",
];


window.onload = function init()
{
  var scene = new THREE.Scene();

  var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.x = -30;
  camera.position.y = 40;
  camera.position.z = 30;
  camera.lookAt(scene.position);


  var axes = new THREE.AxisHelper( 20 ); scene.add(axes);

  var renderer = new THREE.WebGLRenderer();
  renderer.setClearColor(0xEEEEEE);
  renderer.setSize(window.innerWidth, window.innerHeight);

  geometryChao = new THREE.PlaneGeometry( mazedata[0].length * scale, mazedata.length * scale ); // chão com dimensões igual ao labirinto
  materialChao = new THREE.MeshPhongMaterial( {color: 0xd1f5da, map: texturaChao } );
  var chao = new THREE.Mesh(geometryChao, materialChao);
  scene.add(chao);

  desenhaMapa();

  document.body.appendChild( renderer.domElement );
  renderer.render(scene, camera);

}

function desenhaMapa()
{
  labirinto = new THREE.Object3D();

  geometry = new THREE.PlaneGeometry(50,50);
  material = new THREE.MeshPhongMaterial( {color: 0xffffff, map: texturaCaixa} );
  var planoPacMan = new THREE.Mesh(geometry,material);

  for ( var i = 0; i < mazedata.length; i++ )
  {
    for ( var j = 0; j < mazedata[i].length; j++ )
    {
      console.log(i);
      console.log(j);
        if ( mazedata[i][j] == "-" ) // mazecubo
        {
            var plano = meshCubo.clone();
            mazecubo.position.set(j*10, i*10, 0);
            labirinto.add(mazecubo);
        }
    }
  }
  scene.add(labirinto);
}
