// Variáveis globais

var MeshDataPac =
[
  "------------------------------",
  "-ooooooooooooo--ooooooooooooo-",
  "-o----o------o--o------o----o-",
  "-o----o------o--o------o----o-",
  "-oooooooooooooooooooooooooooo-",
  "-o----o--o----------o--o----o-",
  "-oooooo--ooooo--ooooo--oooooo-",
  "------o------ -- ------o------",
  "------o-              -o------",
  "------o-  ----  ----  -o------",
  "-     o-  -        -   o     -",
  "------o-  ----------  -o------",
  "------o-              -o------",
  "------o-  ----------  -o------",
  "-ooooooooooooo--ooooooooooooo-",
  "-o----o------o--o------o----o-",
  "-ooo--oooooooo--ooooooooooooo-",
  "---o--oooo          oooo------",
  "---o--o--o-----------o-o--o---",
  "-oooooo--ooooo--oooooo-o--ooo-",
  "-o-----------o--o-----------o-",
  "-oooooooooooooooXoooooooooooo-",
  "------------------------------"
];

var contagem = 0;

var scene,renderer,camera,light,axes,PacScene,PacMan,direccao,direccaoPac,orbitCamera;
var pontuacao = 0;
var clock = new THREE.Clock();
const SCALE = 10;
const CORPACMAN = 0xffff00;
const VELOCIDADEPAC = 0.5;
const TAMANHOPAC = 2;
const ALTURAPAC = 0;
const INIMIGOS = 4;
const LUZ = 0.5;


// Inicio do programa
window.onload = function init()
{
  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.x = 0;
  camera.position.y = 0;
  camera.position.z = 300;
  camera.up = new THREE.Vector3(0,1,0);
  camera.lookAt(scene.position);
  orbitCamera = new THREE.OrbitControls(camera);
  orbitCamera.target= new THREE.Vector3(0,0,0);
  orbitCamera.maxDistance=500;

  light = new THREE.AmbientLight(0xffffff);
  light.intensity = LUZ;
  scene.add( light );


  axes = new THREE.AxisHelper( 40 );
  axes.position.set(0,0,30);
  scene.add(axes);

  desenhaMapa();

  renderer = new THREE.WebGLRenderer();
  renderer.setClearColor(0xEEEEEE);
  renderer.setSize(window.innerWidth, window.innerHeight);

  var texturaPlano = new THREE.TextureLoader().load("texturaPac.jpg");
  texturaPlano.wrapS = THREE.RepeatWrapping;
  texturaPlano.wrapT = THREE.RepeatWrapping;
  texturaPlano.repeat.set(50,50);

  var geometryPlano = new THREE.PlaneGeometry(MeshDataPac[0].length * SCALE, MeshDataPac.length*SCALE);
  var materialPlano = new THREE.MeshPhongMaterial({map:texturaPlano});
  var planoPacMan = new THREE.Mesh(geometryPlano,materialPlano);
  scene.add(planoPacMan);


  document.body.appendChild( renderer.domElement );
  renderer.render(scene, camera);
  document.onkeypress = handleKeyPressed;

  anima();

}

function desenhaMapa()
{
  PacScene = new THREE.Object3D();

  var Box = new THREE.TextureLoader().load("Box.jpg");

  geometry = new THREE.BoxGeometry( SCALE, SCALE, SCALE );
  material = new THREE.MeshPhongMaterial( {
                                            color: 0xffffff,
                                            wireframe: false,
                                            map: Box
                                        } );

  var PacManGeometry = new THREE.SphereGeometry(TAMANHOPAC,40,40);
  var PacManMaterial = new THREE.MeshPhongMaterial({color: CORPACMAN});
  PacMan = new THREE.Mesh(PacManGeometry,PacManMaterial);
  PacMan.position.y = ALTURAPAC;
  PacMan.name = "PacMan";

  var bolasGeometry = new THREE.SphereGeometry(0.5,16,16);
  var bolaMaterial = new THREE.MeshPhongMaterial( {
                                            color: 0xdcfecc,
                                        } );
  var bolaCollecao = new THREE.Mesh(bolasGeometry,bolaMaterial);

  var meshCubo =  new THREE.Mesh(geometry, material);

  for ( var i = 0; i < MeshDataPac.length; i++ )
  {
    for ( var j = 0; j < MeshDataPac[i].length; j++ )
    {
        if ( MeshDataPac[i][j] == "-" ) // mazecubo
        {
            var mazecubo = meshCubo.clone();
            mazecubo.position.set(j*SCALE,-i*SCALE,SCALE);
            PacScene.add(mazecubo);
        }

      if(MeshDataPac[i][j] == "X")
        {
        PacMan.position.set(j*SCALE,-i*SCALE,SCALE);
        PacScene.add(PacMan);
        }

       if ( MeshDataPac[i][j] == "o" ) // mazecollectable
        {
            var MeshColecao = bolaCollecao.clone();
            MeshColecao.position.set(j*SCALE,-i*SCALE,SCALE + ALTURAPAC*2);
            MeshColecao.name = "collectable" + i + j;
            PacScene.add(MeshColecao);
            contagem++;
        }

    }
    console.log(contagem);
  }
  scene.add(PacScene);
  PacScene.position.set( -MeshDataPac[0].length*SCALE/2, MeshDataPac.length*SCALE/2, (SCALE/2)-SCALE);
  scene.add(camera);

}

 function handleKeyPressed(e) {

   var PacMan = scene.getObjectByName('PacMan');
   switch(String.fromCharCode(e.which))
   {
     case "w": if(!detectaColisao(PacMan.position.x, PacMan.position.y + SCALE))
          PacMan.position.y += SCALE;
       break;
     case "a": if(!detectaColisao(PacMan.position.x - SCALE, PacMan.position.y))
         PacMan.position.x -= SCALE;
       break;
     case "s": if(!detectaColisao(PacMan.position.x, PacMan.position.y - SCALE))
         PacMan.position.y -= SCALE;
       break;
     case "d": if(!detectaColisao(PacMan.position.x + SCALE, PacMan.position.y))
         PacMan.position.x += SCALE;
       break;

   }

       /*if(currentlyPressedKeys[37])
         PacMan.position.x -= SCALE/4;
       if(currentlyPressedKeys[38])
         PacMan.position.z -= SCALE/4;
       if(currentlyPressedKeys[39])
         PacMan.position.x += SCALE/4;
       if(currentlyPressedKeys[40])
         PacMan.position.z += SCALE/4;
       if(currentlyPressedKeys[81])
         PacMan.rotation.y += 0.5*Math.PI;
       if(currentlyPressedKeys[69])
         PacMan.rotation.y -= -0.5*Math.PI;
         */
}


function detectaColisao(x,y)
{
  var j = parseInt(x/SCALE);
  var i = parseInt(-y/SCALE);

  if(MeshDataPac[i][j] == '-')
  {
    return true;
  }
  else if (MeshDataPac[i][j] == 'o') {
    var selectedObject = PacScene.getObjectByName("collectable" + i + j);

        console.log(MeshDataPac[i][j]);
    PacScene.remove(selectedObject);
    MeshDataPac[i] = replaceAt(MeshDataPac[i],j,' ');
    pontuacao++;
    console.log(pontuacao);
  }
  return false;
}

function replaceAt(s,n,t) {

  return s.substring(0,n) + t + s.substring(n+1);
}


/*function verificaColisoes(x,y)
{

  if(i < 0 || i >=MeshDataPac.length)
  {
    return false;
  }


  if(j < 0 || j >= MeshDataPac[0].length)
  {
    return false;
  }


  if(MeshDataPac[i][j] == "-")
  {
    return true;
  }

   if(MeshDataPac[i][j] == "o")
  {

    var selectedObject = labirinto.getObjectByName("bola" + i + j);
    console.log(selectedObject);
    PacScene.remove(selectedObject);
  }
  return false;

}*/


function anima()
{
  var delta=clock.getDelta();
  orbitCamera.update(delta);

  requestAnimationFrame(anima);
  renderer.render(scene, camera);
}
