var scene, camera, renderer;
var geometry, material, meshbase, meshTorre, meshCubo, meshBola, labirinto, meshPlano, meshCanhao, pivotPoint, velocidade = 0, direccao = 0, direccaoRodas = 0, x = 0, y = 0;
const RAIO_ROTACAO=20;

const LARGURA_BASE=4;
const COMPRIMENTO_BASE=7;
const ALTURA_BASE=1;

const LARGURA_TORRE=2;
const COMPRIMENTO_TORRE=2;
const ALTURA_TORRE=0.5;

const COMPRIMENTO_CANHAO=4;
const RAIO_CANHAO=0.2;

var currentlyPressedKeys = {};

var bola;
var d;
var ang;

var angTorre = 0;
var angCanhao = 0;


var mazedata=[
  "                  ",
  " ******* ******** ",
  " *  #    *      * ",
  " * * *** * *    * ",
  " * **  * ** * * * ",
  " *  #  *      * * ",
  " *          *** * ",
  " *      #    *  * ",
  " *     * *** **** ",
  " * *   *   *    * ",
  " *   **** #*    * ",
  " ********  **** * ",
  " *            * * ",
  " *  #  *      * * ",
  " ** ** *    *** * ",
  " *   *  #   *   * ",
  " *******  **** ** ",
  "                  "
];

var scale = 10;


window.onload = function init() {

  document.onkeydown=handleKeyDown;
	document.onkeyup=handleKeyUp;

  scene = new THREE.Scene();

  camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 10000 );
  camera.position.set(-15, 0, 5);
  camera.up = new THREE.Vector3(0,0,1);
  camera.lookAt(new THREE.Vector3(3, 0, 3));

  labirinto = new THREE.Object3D();
  //labirinto
  var imageURL = "lab.jpg";
  var texture = new THREE.TextureLoader().load(imageURL);


  geometry = new THREE.BoxGeometry(scale, scale,scale);
  material = new THREE.MeshPhongMaterial( { color: 0xFFFFFFF, map: texture } );
  meshCubo = new THREE.Mesh(geometry, material);

  bola = new THREE.Object3D();

  geometry = new THREE.SphereGeometry(2, 16,16);
  material = new THREE.MeshPhongMaterial( { color: 0xFFFFFFF} );
  meshBola = new THREE.Mesh(geometry, material);


  for(var i= 0; i < mazedata.length; i++)
  {
    for(var j = 0; j < mazedata[i].length; j++)
    {
      if(mazedata[i][j] == "*")
      {
        var novoCubo = meshCubo.clone();
        novoCubo.position.set(j*scale,i*scale,0);
        labirinto.add(novoCubo);
      }
      if(mazedata[i][j] == "#")
      {
        var novaBola = meshBola.clone();
        novaBola.name = "bola" + i + j;
        console.log(novaBola.name);
        novaBola.position.set(j*scale, i*scale, -3);
        labirinto.add(novaBola);
      }
    }
  }

  labirinto.position.set(-mazedata[0].length * scale / 2, -mazedata.length * scale / 2, scale/2);
  scene.add(labirinto);

  //bola.position.set(-mazedata[0].length * scale / 2 , -mazedata.length * scale  / 2, scale / 2);
  //scene.add(bola);


  //chao
  var imageURL2 = "chao.jpg";
  var texture2 = new THREE.TextureLoader().load(imageURL2);
  geometry = new THREE.PlaneGeometry(mazedata[0].length * scale, mazedata.length * scale);
  material = new THREE.MeshPhongMaterial( { color: 0xFFFFFFF, map: texture2  } );
  meshPlano = new THREE.Mesh(geometry, material);
  scene.add(meshPlano);


  //base
  var imageURL3 = "tanque.jpg";
  var texture3 = new THREE.TextureLoader().load(imageURL3);
  geometry = new THREE.BoxGeometry( COMPRIMENTO_BASE, LARGURA_BASE, ALTURA_BASE );
  material = new THREE.MeshPhongMaterial( { color: 0xFFFFFFF, map: texture3 } );
  meshBase = new THREE.Mesh( geometry, material );
  scene.add( meshBase );
  meshBase.add(camera);

  //torre
  geometry = new THREE.BoxGeometry(COMPRIMENTO_TORRE,LARGURA_TORRE,ALTURA_TORRE);
  material = new THREE.MeshPhongMaterial( { color: 0xB2222 } );
  meshTorre = new THREE.Mesh( geometry, material );
  meshTorre.position.set(0, 0, ALTURA_BASE/2+ALTURA_TORRE/2);

  meshBase.add( meshTorre );

  //canhao
  geometry = new THREE.BoxGeometry(COMPRIMENTO_CANHAO,RAIO_CANHAO*2,RAIO_CANHAO*2);
  material = new THREE.MeshPhongMaterial( { color: 0xFF0000 } );
  meshCanhao = new THREE.Mesh( geometry, material );
  meshCanhao.position.set(COMPRIMENTO_CANHAO/2, 0, 0);

  pivotPoint = new THREE.Object3D();
  pivotPoint.position.set(COMPRIMENTO_TORRE/2, 0, 0);

  meshTorre.add( pivotPoint);
  pivotPoint.add(meshCanhao);

  //distancia e anguloxz
  d = Math.sqrt(Math.pow(LARGURA_BASE / 2, 2) + Math.pow(COMPRIMENTO_BASE / 2, 2));
  ang = Math.atan2(LARGURA_BASE/2, COMPRIMENTO_BASE/2);

  //add a directional light to show off the object
   var light = new THREE.DirectionalLight(0xffffff, 1.5);
  //Position the light out from the scene, pointing at the origin
  light.position.set(0.3, 0.6, 1);
  scene.add(light);


  var lightTarget = new THREE.Object3D();
  lightTarget.position.set(COMPRIMENTO_CANHAO, 0, 0);
  meshCanhao.add(lightTarget);

  var light2 = new THREE.SpotLight(0xffffff);
  //Position the light out from the scene, pointing at the origin
  light2.position.set(0, 0, 0);
  light2.angle =0.2;
  light2.target = lightTarget;
  light2.penumbra = 0.5;
  meshCanhao.add(light2);


  renderer = new THREE.WebGLRenderer();
  renderer.setSize( window.innerWidth, window.innerHeight );


  document.body.appendChild( renderer.domElement );


  animate();

}



function handleKeyDown(e) {

	currentlyPressedKeys[e.keyCode] = true;
	switch( String.fromCharCode(e.keyCode)) {
		case "i" :
		case "I" :
				modelo.tanque.x=modelo.tanque.y=modelo.tanque.z=0;
			break;
		case "o" :
		case "O" :
				modelo.ortho=!modelo.ortho;
				setProjection();
			break;


	}
	console.log("Tecla Pressionada: "+e.keyCode);
}

function radians(ang)
{
  return ang * Math.PI / 180;
}

function handleKeyUp(e) {

	currentlyPressedKeys[e.keyCode] = false;
	switch( String.fromCharCode(e.keyCode)) {
	}
	console.log("Tecla Largada: "+e.keyCode);
}

function handleKeys()
{
  if(currentlyPressedKeys[81] && angCanhao < radians(5)) //q
	{
		angCanhao+= 0.01;
	}
	if(currentlyPressedKeys[65] && angCanhao > radians(-50)) //a
	{
		angCanhao-=0.01;
	}
	if(currentlyPressedKeys[90]) //z
	{
		angTorre+=0.01;
	}
	if(currentlyPressedKeys[88]) //x
	{
		angTorre-=0.01;
	}


	if(currentlyPressedKeys[38] && velocidade < 0.5) //seta up
	{
		velocidade += 0.1;
    direcao = -0.5 * Math.PI;
	}
		if(currentlyPressedKeys[40] && velocidade > -0.5) //seta down
	{
		velocidade -= 0.1;
    direcao = -0.5 * Math.PI;
	}
	if(currentlyPressedKeys[37]  && direccaoRodas < 0.05)//seta esquerda
	{
		direccaoRodas +=0.01;
    direcao = -0.5 * Math.PI;
	}
		if(currentlyPressedKeys[39] && direccaoRodas > -0.05) //seta direita
	{
		direccaoRodas-=0.01;
    direcao = -0.5 * Math.PI;
	}

	if(!currentlyPressedKeys[38] && !currentlyPressedKeys[40])
	{
		velocidade *= 0.9;
		if(Math.abs(velocidade) <= 0.01)
		{
			velocidade = 0;
		}
	}
  if(!currentlyPressedKeys[37] && !currentlyPressedKeys[39])
	{
    if(velocidade != 0)
		  direccaoRodas = direccaoRodas* 0.95 ;
	}


}

function colisao(x,y)
{

  var i = parseInt((y + mazedata.length * scale / 2) / scale+0.5);
  var j = parseInt((x + mazedata[0].length *scale / 2) / scale+0.5);

  if(i < 0 || i >=mazedata.length)
  {
    return false;
  }


  if(j < 0 || j >= mazedata[0].length)
  {
    return false;
  }


  if(mazedata[i][j] == "*")
  {
    return true;
  }

   if(mazedata[i][j] == "#")
  {

   var selectedObject = labirinto.getObjectByName("bola" + i + j);
    console.log(selectedObject);
    labirinto.remove(selectedObject);
  }
  return false;

}

function animate() {

  handleKeys();
	direccao += direccaoRodas * velocidade;
  var nx = x+velocidade * Math.cos(direccao);
  var ny = y+velocidade * Math.sin(direccao);

  if(velocidade > 0)
  {

    if(!colisao(nx + d * Math.cos(direccao), ny + d * Math.sin(direccao))
      && !colisao(nx + d * Math.cos(direccao), ny + d * Math.sin(direccao)))
    {
      x=nx;
      y=ny;
    }
  }
  else
  {
    if(!colisao(nx - d * Math.cos(direccao), ny - d * Math.sin(direccao))
      && !colisao(nx - d * Math.cos(direccao), ny - d * Math.sin(direccao)))
    {
      x=nx;
      y=ny;
    }

  }

  meshTorre.rotation.z = angTorre;
  pivotPoint.rotation.y = angCanhao;

  meshBase.position.set(x, y, 1);


  requestAnimationFrame( animate );




  meshBase.rotation.z = direccao;
  //meshTorre.rotation.z -= 0.02;
  //pivotPoint.rotation.y -= 0.01;
  //camera.lookAt(new THREE.Vector3(x, y, 0));

  renderer.render( scene, camera );

}
