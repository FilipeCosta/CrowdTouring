function guardar()
{
	var nome = document.getElementById("nome").value;
	var url = document.getElementById("url").value;
	localStorage.setItem(nome,url);
	 document.getElementById("nome").value = "";
	document.getElementById("url").value = "";
	
	mostraTabela();
}

function remove()
{
	var nome = document.getElementById("nome").value;
	localStorage.removeItem(localStorage.getItem(nome));
}

function removeParcial()
{
	var nome = document.getElementById("nome").value;
	localStorage.removeItem(localStorage.getItem(nome));
	for (i = 0; i <= localStorage.length - 1; i++)
		 {
			if(localStorage.getItem(key).charAt(0) == nome.charAt(0))
			{
				localStorage.removeItem(localStorage.getItem;
			}
		}
}

function removeAll()
{
	localStorage.clear();
	mostraTabela();
}

function alterar()
{
	var nome = document.getElementById("nome").value;
	document.getElementById("url").value = localStorage.getItem(nome);
	
	mostraTabela();
}

function mostraTabela()
{	
	if (typeof(Storage) != "undefined") {
		var key = "";
		var i = 0;
		var list = "<tr><th colspan = 2>meus bookmarks</th></tr>\n <tr><td>numero de bookmarks</td><td>" + localStorage.length + "</td</tr>\n<tr><td>nome</td><td>Url</td>\n" ;	
		for (i = 0; i <= localStorage.length - 1; i++)
		 {
			key = localStorage.key(i);
			list += "<tr><td>" + key + "</td>\n<td>"
					+ localStorage.getItem(key) + "</td></tr>\n";
		}
		
		document.getElementById('myTabel').innerHTML = list;
	} else {
		alert("O browser não suporta a API Web Storage");
	}
}

function segundoVideo()
{
    var vid = "<iframe width=600 height=600 src=https://www.youtube.com/embed/w9Mp8YGh0tg frameborder=0 allowfullscreen></iframe>";
	var refVid = document.getElementById("video2");
	refVid.innerHTML = vid;
}



