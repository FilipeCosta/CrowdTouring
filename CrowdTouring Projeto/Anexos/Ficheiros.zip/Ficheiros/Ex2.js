window.onload = function () {
    var canvas = document.getElementById('myCanvas');
    if (canvas.getContext) {
        var ctx = canvas.getContext('2d');
    
        ctx.translate(canvas.width/2,canvas.height/2);
        function desenhaPacManA()
        {
            ctx.beginPath();
            
            ctx.fillStyle = "yellow";
            ctx.arc(0,0,50,Math.PI/180*50,Math.PI/180*(-50));
            ctx.fill();
            
           
            ctx.fillStyle = "white";
            ctx.moveTo(0,0);
            ctx.lineTo(50*Math.cos(50*Math.PI/180),50*Math.sin(50*Math.PI/180));
            ctx.moveTo(0,0);
            ctx.lineTo(50*Math.cos(-(50*Math.PI/180)),50*Math.sin(-(50*Math.PI/180)));
            ctx.moveTo(50*Math.cos(50*Math.PI/180),50*Math.sin(50*Math.PI/180));
            ctx.stroke();
            ctx.closePath();
            
            ctx.beginPath();
            ctx.fillStyle = "black";
            ctx.arc(0,-25,5,0,2*Math.PI);
            ctx.fill();
            
            ctx.beginPath();
            ctx.fillStyle = "yellow";
            ctx.arc(0,0,50,0,2*Math.PI);
            ctx.fill();
            ctx.stroke();
            ctx.beginPath();
            ctx.fillStyle = "black";
            ctx.arc(0,-25,5,0,2*Math.PI);
            ctx.fill();
            ctx.beginPath();
            ctx.moveTo(0,0);
            ctx.lineTo(50,0);
            ctx.stroke();
         
           
            
             
            
        }
        
        
           
            
   
        
     
        
        
        
       
        function openClouse()
        {
            canvas.width = canvas.width;
            ctx.translate(canvas.width/2,canvas.height/2);
            desenhaPacManA(); 
        }
        
        window.setInterval(openClouse,500);
    }
}