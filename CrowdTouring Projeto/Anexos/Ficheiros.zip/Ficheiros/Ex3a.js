window.onload = function () {
    var canvas = document.getElementById('myCanvas');
    if (canvas.getContext) {
        var ctx = canvas.getContext('2d');
        
        
        function asEspadas()
        {
        ctx.translate(canvas.width/2,canvas.height/2);
        ctx.beginPath();
        ctx.moveTo(0,-100);
        ctx.bezierCurveTo(60,-70,100,-40,100,20);
        ctx.arc(50,20,50,0,Math.PI);
        
        ctx.quadraticCurveTo(10,90,20,100);
        ctx.lineTo(-20,100);
        ctx.quadraticCurveTo(-10,90,0,20);
       
           ctx.arc(-50,20,50,0,Math.PI);
        ctx.bezierCurveTo(-100,-40,-60,-70,0,-100);
     
        
        ctx.stroke();
    }
        asEspadas();
   
    }
}