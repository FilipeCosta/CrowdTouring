window.onload = function () {
    var canvas = document.getElementById('myCanvas');
    if (canvas.getContext) {
        var ctx = canvas.getContext('2d');
        var text = prompt("escreva uma palavra:","Hello");
        
function desenhaPalavra(text)
        {
        
            ctx.font = "40px Arial";
            ctx.scale(1,-1);
            ctx.fillText(text,canvas.width/2,canvas.height/2);
            ctx.fillStyle = "blue";
            ctx.shadowOffsetY = 40; 
            ctx.shadowColor = "blue";
            ctx.shadowBlur = 5;         
            ctx.fillText(text,canvas.width/2,-canvas.height/2);
            
           
           
        }

desenhaPalavra(text);
    }
}