window.onload = function () {
    var canvas = document.getElementById('myCanvas');
    if (canvas.getContext) {
        var ctx = canvas.getContext('2d');
        
        
       
        function asEspadas()
        {
       
        ctx.beginPath();
        ctx.strokeStyle = "yellow";
        ctx.moveTo(0,-100);
        ctx.bezierCurveTo(60,-70,100,-40,100,20);
        ctx.arc(50,20,50,0,Math.PI);
        
        ctx.quadraticCurveTo(10,90,20,100);
        ctx.lineTo(-20,100);
        ctx.quadraticCurveTo(-10,90,0,20);
       
           ctx.arc(-50,20,50,0,Math.PI);
        ctx.bezierCurveTo(-100,-40,-60,-70,0,-100);
     
        
        ctx.stroke();
        ctx.fill();
    }
        ctx.fillStyle = "white";
        ctx.strokeStyle = "yellow";
        ctx.lineWidth = 5; 
        ctx.translate(canvas.width/2,canvas.height/2);
        ctx.fillRect(-150,-200,300,400);
        ctx.strokeRect(-150,-200,300,400);
        ctx.fillStyle = "black";
        asEspadas();
        ctx.font = "bold 36px sans-serif";
       ctx.fillText("A",-140,-170);
       ctx.translate(-127,-145);
         ctx.scale(0.2,0.2);        
        asEspadas();
        
   
    }
    }
