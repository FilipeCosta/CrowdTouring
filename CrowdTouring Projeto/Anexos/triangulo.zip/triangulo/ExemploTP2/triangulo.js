var gl;
var pontos = [];

window.onload = function init()
{
	var canvas = document.getElementById('gl-canvas');
	gl=WebGLUtils.setupWebGL(canvas);

	if(!gl)	{alert("WebGL não está disponível"); }

	

	// Configurar o WebGL

	gl.viewport( 0, 0, canvas.width, canvas.height);
	gl.clearColor(1.0, 1.0, 1.0, 1.0);

	// Carregar os shaders e incializar os buffers de atributos

	var program = initShaders( gl, "vertex-shader", "fragment-shader");

	gl.useProgram(program);

	// Carregar dados para o GPU

	var bufferId = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, bufferId);
	

	// Associar variáveis do shader aos Buffers de dados

	var vPosition = gl.getAttribLocation(program, "vPosition");
	gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
	gl.enableVertexAttribArray(vPosition);
	render();
};

function render(numLados)
{
	gl.clear(gl.COLOR_BUFFER_BIT);
	gl.drawArrays(gl.TRIANGLE_FAN, 0, numLados);
	gl.drawArrays(gl.LINE_LOOP, numLados,10);
}

function poligono(numLados,xCentro,yCentro,raio)
{
		var angulo = 2*Math.PI/numLados;
		var temp = 0;
		for(var i = 0;i<numLados;i++)
		{
			var x = xCentro + raio * Math.cos(temp);
			var y = yCentro + raio * Math.sin(temp);
			temp+=angulo;
			pontos.push(x);
			pontos.push(y);
		}
}

function poligonoGeral()
{
	var numLados = parseInt(document.getElementById("numLados").value);
	var xCentro = parseFloat(document.getElementById("x").value);
	var yCentro = parseFloat(document.getElementById("y").value);
	var raio = parseFloat(document.getElementById("raio").value);

	
	poligono(numLados,xCentro,yCentro,raio);
	
	poligono2();
	
	gl.bufferData(gl.ARRAY_BUFFER, flatten(pontos), gl.STATIC_DRAW);
	
	render(numLados);
	
	pontos = [];
	
}

function poligono2()
{
		var angulo = 2*Math.PI/10;
		var temp = 0;
		for(var i = 0;i<10;i++)
		{
			var x = 0.3 + 0.4 * Math.cos(temp);
			var y = -0.4 + 0.4 * Math.sin(temp);
			temp+=angulo;
			pontos.push(x);
			pontos.push(y);
		}	
}